package loan_application_verification;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class admin_bank_info extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTable table;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admin_bank_info frame = new admin_bank_info();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public admin_bank_info() {
		setBackground(new Color(128, 0, 0));
		setResizable(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setEnabled(false);
		scrollPane.setFocusTraversalKeysEnabled(false);
		scrollPane.setFocusable(false);
		scrollPane.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		scrollPane.setForeground(new Color(0, 139, 139));
		scrollPane.setBackground(new Color(175, 238, 238));
		scrollPane.setBounds(66, 131, 410, 298);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel = new JLabel("Bank List");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 36));
		lblNewLabel.setBounds(96, 10, 438, 35);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//Write code to search data for Userid
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/loanapplication","root","jfb@2410"); 
					Statement stmt=con.createStatement();
					//JOptionPane.showMessageDialog(null,"select name, name, = '"+textField_6.getText()+"'");
					ResultSet rs=stmt.executeQuery("select * bank_name from bank_list where bank_name = '"+textField.getText()+"'");
					while(rs.next())
					{
						textField.setText(rs.getString(1));
		
					}
			} catch(Exception e1) {
				e1.printStackTrace();
			}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(525, 220, 107, 35);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("add");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@SuppressWarnings("unused")
			@Override
			public void mouseClicked(MouseEvent e) {
				//Write code to search data for Userid
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/loanapplication","root","jfb@2410"); 
					String query="update bank_list set bank= '"+ textField.getText() +"' where bank_name = +textField.getText()+";
					//Statement stmt=con.createStatement();
					//JOptionPane.showMessageDialog(null,"select name, name, = '"+textField_6.getText()+"'");
					//ResultSet rs=stmt.executeQuery("select * first_name, last_name, address, loan_type, loan_amount, cibil_score from client_registeratio where first_name = '"+textField.getText()+"'");
					PreparedStatement preparedStmt= con.prepareStatement(query);
					JOptionPane.showMessageDialog(null,  "Details Successfully updated. Please load table again to refresh");
					
					
						textField.setText(null);
		con.close();
		
					
			} catch(Exception e1) {
				e1.printStackTrace();
			}
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_1.setBounds(525, 278, 107, 35);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("remove");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@SuppressWarnings("unused")
			@Override
			public void mouseClicked(MouseEvent e) {
				//Write code to search data for Userid
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/loanapplication","root","jfb@2410"); 
					String query="delete from bank_list where bank_name= '" +textField.getText()+"'";
					//Statement stmt=con.createStatement();
					//JOptionPane.showMessageDialog(null,"select name, name, = '"+textField_6.getText()+"'");
					//ResultSet rs=stmt.executeQuery("select * first_name, last_name, address, loan_type, loan_amount, cibil_score from client_registeratio where first_name = '"+textField.getText()+"'");
					PreparedStatement preparedStmt= con.prepareStatement(query);
					JOptionPane.showMessageDialog(null,  "Details Successfully updated. Please load table again to refresh");
					
					
						textField.setText(null);
		con.close();
		
					
			} catch(Exception e1) {
				e1.printStackTrace();
			}
			}
		});
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_2.setBounds(525, 333, 107, 35);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("load table");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try{  
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/loanapplication","root","jfb@2410");  
					Statement stmt=con.createStatement();
					
					String query= "select * bank_name from bank_list order by bank_name";
					PreparedStatement pst=con.prepareStatement(query);
					ResultSet rs= pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rs));
					table.setEnabled(false);
					con.close();
				}catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnNewButton_3.setBounds(66, 89, 85, 21);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("back");
		btnNewButton_4.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnNewButton_4.setBounds(371, 89, 105, 21);
		contentPane.add(btnNewButton_4);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(new Color(0, 0, 0));
		separator.setBackground(new Color(0, 0, 0));
		separator.setBounds(136, 55, 356, 2);
		contentPane.add(separator);
		
		textField = new JTextField();
		textField.setBounds(516, 142, 127, 62);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Bank Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(516, 100, 127, 30);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_5 = new JButton("Home");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				admin_home admin= new admin_home();
				admin.setVisible(true);	
			}
		});
		btnNewButton_5.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_5.setBounds(524, 378, 108, 51);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("X");
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		btnNewButton_6.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_6.setBounds(644, 0, 56, 45);
		contentPane.add(btnNewButton_6);
		setUndecorated(true); //To remove frame outline
	}
}
