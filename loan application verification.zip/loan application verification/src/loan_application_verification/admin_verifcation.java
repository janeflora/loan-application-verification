package loan_application_verification;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.UIManager;

public class admin_verifcation extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admin_verifcation frame = new admin_verifcation();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public admin_verifcation() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Loan Verification");
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 36));
		lblNewLabel.setBounds(153, 10, 353, 44);
		contentPane.add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(new Color(0, 0, 0));
		separator.setBackground(new Color(0, 0, 0));
		separator.setBounds(163, 56, 324, 10);
		contentPane.add(separator);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setEnabled(false);
		scrollPane.setFocusTraversalKeysEnabled(false);
		scrollPane.setFocusable(false);
		scrollPane.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 5));
		scrollPane.setForeground(new Color(0, 139, 139));
		scrollPane.setBackground(new Color(175, 238, 238));
		scrollPane.setBounds(32, 130, 474, 313);
		contentPane.add(scrollPane);
		
		JButton btnNewButton_1 = new JButton("search");
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_1.setBounds(529, 274, 120, 36);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("approve");
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_2.setBounds(527, 320, 122, 52);
		contentPane.add(btnNewButton_2);
		
		textField = new JTextField();
		textField.setBounds(527, 175, 122, 70);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("applications");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				admin_applications admin= new admin_applications();
				admin.setVisible(true);	
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton.setBounds(529, 382, 120, 36);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_3 = new JButton("load table");
		btnNewButton_3.setBackground(new Color(240, 240, 240));
		btnNewButton_3.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		btnNewButton_3.setBounds(32, 91, 85, 29);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("back");
		btnNewButton_4.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		btnNewButton_4.setBounds(417, 91, 85, 29);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("X");
		btnNewButton_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		btnNewButton_5.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_5.setBounds(641, 0, 59, 44);
		contentPane.add(btnNewButton_5);
		setUndecorated(true); //To remove frame outline
	}

}
