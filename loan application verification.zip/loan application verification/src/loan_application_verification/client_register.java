package loan_application_verification;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JButton;

public class client_register extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					client_register frame = new client_register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public client_register() {
		setBackground(new Color(128, 0, 0));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("client registeration");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 36));
		lblNewLabel.setBounds(161, 10, 348, 43);
		contentPane.add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(new Color(0, 0, 0));
		separator.setBackground(new Color(0, 0, 0));
		separator.setBounds(171, 63, 338, 10);
		contentPane.add(separator);
		
		JLabel lblNewLabel_1 = new JLabel("first name");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_1.setBounds(26, 101, 118, 33);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("last name");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_2.setBounds(26, 169, 118, 33);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("age");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_3.setBounds(26, 233, 118, 33);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("gender");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_4.setBounds(26, 297, 118, 33);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("nationality");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_5.setBounds(26, 355, 118, 33);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Address");
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_6.setBounds(26, 415, 118, 33);
		contentPane.add(lblNewLabel_6);
		
		textField = new JTextField();
		textField.setBounds(151, 103, 156, 33);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(151, 171, 156, 33);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(151, 235, 156, 33);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(151, 299, 156, 33);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(151, 357, 156, 33);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(151, 417, 156, 79);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("contact No.");
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_7.setBounds(336, 103, 125, 33);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("CIBIL score");
		lblNewLabel_8.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_8.setBounds(336, 169, 125, 33);
		contentPane.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("loan type ");
		lblNewLabel_9.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_9.setBounds(336, 233, 125, 33);
		contentPane.add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("loan amount");
		lblNewLabel_10.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_10.setBounds(336,297, 125, 33);
		contentPane.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("period");
		lblNewLabel_11.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_11.setBounds(336, 355, 125, 33);
		contentPane.add(lblNewLabel_11);
		
		textField_6 = new JTextField();
		textField_6.setBounds(471, 103, 156, 33);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(471, 171, 156, 33);
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setBounds(471, 235, 156, 33);
		contentPane.add(textField_8);
		textField_8.setColumns(10);
		
		textField_9 = new JTextField();
		textField_9.setBounds(471, 299, 156, 33);
		contentPane.add(textField_9);
		textField_9.setColumns(10);
		
		textField_10 = new JTextField();
		textField_10.setBounds(471, 357, 156, 33);
		contentPane.add(textField_10);
		textField_10.setColumns(10);
		
		JButton btnNewButton = new JButton("Next");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				client_guaranter client= new client_guaranter();
				client.setVisible(true);	
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 19));
		btnNewButton.setBounds(346, 450, 118, 43);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("X");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_1.setBounds(630, 0, 70, 43);
		contentPane.add(btnNewButton_1);
		
		textField_11 = new JTextField();
		textField_11.setBounds(471, 415, 156, 28);
		contentPane.add(textField_11);
		textField_11.setColumns(10);
		
		JLabel lblNewLabel_12 = new JLabel("Bank Acc. No.");
		lblNewLabel_12.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_12.setBounds(336, 415, 125, 25);
		contentPane.add(lblNewLabel_12);
		
		JButton btnNewButton_2 = new JButton("register");
		btnNewButton_2 .addMouseListener(new MouseAdapter()  {
//			public void actionPerformed(ActionEvent e) {
			public void mouseClicked(MouseEvent e) {
				String first_name = textField.getText();
				String last_name=textField_1.getText();
				String age=textField_2.getText();
				String gender=textField_3.getText();
				String nationality= textField_4.getText();
				String address= textField_5.getText();
				String contact_no= textField_6.getText();
				String cibil_score= textField_7.getText();
				String loan_type= textField_8.getText();
				String loan_amount= textField_9.getText();
				String period= textField_10.getText();
				String acc_no= textField_11.getText();
                
                int len = contact_no.length();
                if(len!=10)
                	{JOptionPane.showMessageDialog(btnNewButton_2 ,"Enter a valid mobile number.");
                	//System.exit(-1);
                	 return;}

               
                
                
                String msg = "" + first_name;
                msg += " \n";
                
                try {
                    
                	Class.forName("com.mysql.jdbc.Driver");  
                	Connection con= DriverManager.getConnection ("jdbc:mysql://localhost:3306/loanapplication","root","jfb@2410"); 
                	Statement stmt=con.createStatement();
                    
                    
       
                        String query = "INSERT INTO client_registeration (first_name, last_name, age, gender, nationality, , address, contact_no, cibil_score, loan_type,loan_amount, period, acc_no ) values ('"+ first_name + "','" + last_name+ "','" +age+ "','" +gender+ "','" +nationality+ "','" + address+ "','" +contact_no+ "','" +cibil_score+ "','" +loan_type+ "','" +loan_amount+ "','" +period+ "','" +acc_no ;
                    	
                        
                        boolean x = stmt.execute(query);
                        if (x) {
                        	JOptionPane.showMessageDialog(btnNewButton_2 ,"Unexpected error occured. Please contact ADMIN.");
                        } else {
                        	JOptionPane.showMessageDialog(btnNewButton_2 , "Welcome, " + msg + "Your account is successfully created");
                        	textField.setText(null);
            				textField_1.setText(null);
            				textField_2.setText(null);
            				textField_3.setText(null);
            				textField_4.setText(null);    
            				textField_5.setText(null);
            				textField_6.setText(null);
            				textField_7.setText(null);
            				textField_8.setText(null);
            				textField_9.setText(null);
            				textField_10.setText(null);
            				textField_11.setText(null);
                        }
                    
                    
                    con.close();
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(btnNewButton_2 , exception);
//                  System.out.println(exception);  
                }
            }
			}
        );
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 19));
		btnNewButton_2.setBounds(471, 450, 156, 43);
		contentPane.add(btnNewButton_2);
		setUndecorated(true); //To remove frame outline
	}
}
