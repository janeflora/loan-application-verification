package loan_application_verification;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JButton;

public class client_guaranter extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					client_guaranter frame = new client_guaranter();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public client_guaranter() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("guaranter");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 36));
		lblNewLabel.setBounds(173, 10, 352, 43);
		contentPane.add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(new Color(0, 0, 0));
		separator.setBackground(new Color(0, 0, 0));
		separator.setBounds(211, 63, 269, 13);
		contentPane.add(separator);
		
		JLabel lblNewLabel_1 = new JLabel("first name");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_1.setBounds(43, 112, 119, 31);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("last name");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_2.setBounds(43, 178, 119, 31);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("age");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_3.setBounds(43, 252, 119, 31);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("address");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_4.setBounds(43, 335, 119, 31);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("contact No.");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_5.setBounds(347, 112, 119, 31);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("job status");
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_6.setBounds(347, 178, 119, 31);
		contentPane.add(lblNewLabel_6);
		
		textField = new JTextField();
		textField.setBounds(144, 112, 148, 31);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(144, 180, 148, 31);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(144, 254, 148, 31);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(144, 337, 148, 109);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(488, 112, 139, 31);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(488, 177, 139, 32);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnNewButton = new JButton("Register");
		btnNewButton .addMouseListener(new MouseAdapter()  {
//			public void actionPerformed(ActionEvent e) {
			public void mouseClicked(MouseEvent e) {
				String first_name = textField.getText();
				String last_name=textField_1.getText();
				String age=textField_2.getText();
				String address=textField_3.getText();
				String contact_no= textField_4.getText();
				String job_status= textField_5.getText();
				String acc_no= textField_6.getText();
                
                int len = contact_no.length();
                if(len!=10)
                	{JOptionPane.showMessageDialog(btnNewButton ,"Enter a valid mobile number.");
                	//System.exit(-1);
                	 return;}

               
                
                
                String msg = "" + first_name;
                msg += " \n";
                
                try {
                    
                	Class.forName("com.mysql.jdbc.Driver");  
                	Connection con= DriverManager.getConnection ("jdbc:mysql://localhost:3306/loanapplication","root","jfb@2410"); 
                	Statement stmt=con.createStatement();
                    
                    
       
                        String query = "INSERT INTO client_registeration (first_name, last_name, age, address, contact_no, job_status, acc_no ) values ('"+ first_name + "','" + last_name+ "','" +age+ "','"  + address+ "','" +contact_no+ "','" +job_status+ "','"  +acc_no ;
                    	
                        
                        boolean x = stmt.execute(query);
                        if (x) {
                        	JOptionPane.showMessageDialog(btnNewButton ,"Unexpected error occured. Please contact ADMIN.");
                        } else {
                        	JOptionPane.showMessageDialog(btnNewButton , "Welcome, " + msg + "Your account is successfully created");
                        	textField.setText(null);
            				textField_1.setText(null);
            				textField_2.setText(null);
            				textField_3.setText(null);
            				textField_4.setText(null);    
            				textField_5.setText(null);
            				textField_6.setText(null);
         
                        }
                    
                    
                    con.close();
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(btnNewButton , exception);
//                  System.out.println(exception);  
                }
            }
			}
        );
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 23));
		btnNewButton.setBounds(434, 306, 166, 43);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Home");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				client_home client= new client_home();
				client.setVisible(true);	
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 23));
		btnNewButton_1.setBounds(434, 381, 166, 43);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("X");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_2.setBounds(630, 0, 70, 43);
		contentPane.add(btnNewButton_2);
		
		textField_6 = new JTextField();
		textField_6.setBounds(488, 232, 139, 31);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Bank Acc. No.");
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel_7.setBounds(347, 232, 133, 31);
		contentPane.add(lblNewLabel_7);
	
		setUndecorated(true); //To remove frame outline
	}

}
