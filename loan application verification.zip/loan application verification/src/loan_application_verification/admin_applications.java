package loan_application_verification;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTextField;

public class admin_applications extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admin_applications frame = new admin_applications();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public admin_applications() {
		setBackground(new Color(128, 0, 0));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Application Info");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 36));
		lblNewLabel.setBounds(173, 10, 312, 38);
		contentPane.add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBackground(new Color(0, 0, 0));
		separator.setForeground(new Color(0, 0, 0));
		separator.setBounds(149, 58, 336, 5);
		contentPane.add(separator);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setEnabled(false);
		scrollPane.setFocusTraversalKeysEnabled(false);
		scrollPane.setFocusable(false);
		scrollPane.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 5));
		scrollPane.setForeground(new Color(0, 139, 139));
		scrollPane.setBackground(new Color(175, 238, 238));
		scrollPane.setBounds(22, 133, 474, 304);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		
		JButton btnNewButton = new JButton("Load Table");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try{  
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/loanapplication","root","jfb@2410");  
					Statement stmt=con.createStatement();
					
					String query= "select * first_name, last_name, address, loan_type, loan_amount, cibil_score from client_registeration order by first_name";
					PreparedStatement pst=con.prepareStatement(query);
					ResultSet rs= pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rs));
					table.setEnabled(false);
					con.close();
				}catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 13));
		btnNewButton.setBounds(22, 92, 93, 21);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("back");
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 13));
		btnNewButton_1.setBounds(407, 92, 85, 21);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Search");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//Write code to search data for Userid
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/loanapplication","root","jfb@2410"); 
					Statement stmt=con.createStatement();
					//JOptionPane.showMessageDialog(null,"select name, name, = '"+textField_6.getText()+"'");
					ResultSet rs=stmt.executeQuery("select * first_name, last_name, address, loan_type, loan_amount, cibil_score from client_registeratio where first_name = '"+textField.getText()+"'");
					while(rs.next())
					{
						textField.setText(rs.getString(1));
		
					}
			} catch(Exception e1) {
				e1.printStackTrace();
			}
			}
		});
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_2.setBounds(521, 247, 121, 38);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Verify");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@SuppressWarnings("unused")
			@Override
			public void mouseClicked(MouseEvent e) {
				//Write code to search data for Userid
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/loanapplication","root","jfb@2410"); 
					String query="update client_registeration set verify= '"+ 1 +"' where verify = +textField.getText()+";
					//Statement stmt=con.createStatement();
					//JOptionPane.showMessageDialog(null,"select name, name, = '"+textField_6.getText()+"'");
					//ResultSet rs=stmt.executeQuery("select * first_name, last_name, address, loan_type, loan_amount, cibil_score from client_registeratio where first_name = '"+textField.getText()+"'");
					PreparedStatement preparedStmt= con.prepareStatement(query);
					JOptionPane.showMessageDialog(null,  "Details Successfully updated. Please load table again to refresh");
					
					
						textField.setText(null);
		con.close();
		
					
			} catch(Exception e1) {
				e1.printStackTrace();
			}
			}
		});
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_3.setBounds(521, 308, 121, 38);
		contentPane.add(btnNewButton_3);
		
		textField = new JTextField();
		textField.setBounds(521, 164, 121, 60);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("user ID");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 17));
		lblNewLabel_1.setBounds(521, 133, 121, 21);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_4 = new JButton("Home");
		btnNewButton_4.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				admin_home admin= new admin_home();
				admin.setVisible(true);	
			}
		});
		btnNewButton_4.setBounds(521, 372, 121, 38);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("X");
		btnNewButton_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		btnNewButton_5.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_5.setBounds(641, 0, 59, 48);
		contentPane.add(btnNewButton_5);
	
		setUndecorated(true); //To remove frame outline
	}

}
